<?php

class Site {

    var $id = null;
    var $app = null;
    var $type = null;
    var $env = null;
    var $url = null;
    var $status = null;
    var $version = null;
    var $js = false; //geeft aan of deze via javascript moet worden opgehaald, standaard false

    function __construct($app = null, $type = null, $env = null, $url = null) {
        $this->app = $app;
        $this->type = $type;
        $this->env = $env;
        $this->url = $url;
    }

}

class Status {
    
    var $id = null;
    var $site_id = null;
    var $raw = null;
    var $status = null;    
    var $version = null;
    var $run_id = null;
    var $http_code;

}

class Incident{
    var $id = null;
    var $site_id = null;
    var $call_im = null;
    var $timestamp = null;    
    var $by = null;
    var $remarks = null;
}

Class SiteStatus{
    var $status = null;
    var $version = null;
    var $hd_free_space = null;
    var $interface = null;
}

class Parser{
    
    public static function parse_raw_data($raw){
        $retval = new SiteStatus();
        
        if(json_decode($raw)){
            $st = json_decode($raw);
            if(isset($st->status)){
                $retval->status =  $st->status;
                $retval->version = $st->version;
                $retval->hd_free_space = $st->hd_free_space;                
            }else if(isset($st->appStatus)){
                $retval->status =  $st->appStatus;
                $retval->version = $st->appVersion;
                if(isset($st->freeDiskSpace))
                    $retval->hd_free_space = $st->freeDiskSpace;                
                if(isset($st->interfaceConn))
                    $retval->interface = $st->interfaceConn;                
            }            
        }else{                         
            if (strpos($raw, "Health check test : OK") > 1) {
                $retval->status = "ok";
            }
            $pos = strpos($raw, "version:");
            $retval->version = trim(strip_tags(substr($raw, $pos + 8, strlen($raw))));                
        }   
        
        //check for empty statuses
        if($retval->status==null){
            $retval->status="nok";
        }
        
        return $retval;
    }
}

