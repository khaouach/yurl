/* User interface highlighting of items on mouseover (only client-side visual feedback) */
/* fde/emakina 2006 */

var uiTables = {
	
	TABULAR_TABLE_CLASS: 'cstp-tabular',		// class that identifies tabular data tables
	COLHEADINGS_ROW_CLASS: 'col-headings',	// class that identifies the row with column headings
	
	COLHEADING_HIGHLIGHT_CLASS: 'hover',	// class applied to column heading on hover
	DATAROW_HIGHLIGHT_CLASS: 'hover',		// class applied to table row on focus (to help reading data)

	init: function() {
		// add row highlight events to tabular data tables
		
		var i, j, iTable;

		// look for tabular data tables
		var tables = myDom.getElementsByClassName(document, 'table', this.TABULAR_TABLE_CLASS);
		for (iTable=0; iTable < tables.length; iTable++) {

/*
			// col headings hightlight on mouseover
			var trs = myDom.getElementsByClassName(tables[iTable], 'tr', this.COLHEADINGS_ROW_CLASS);
			for(i=0;i<trs.length;i++) {
				var ths = trs[i].getElementsByTagName('th');
				for (j=0;j<ths.length;j++) {
					// if it contains a link then we'll assume it can be clicked for some sorting or such
					if (ths[j].getElementsByTagName('a').length) {
						ths[j].onmouseover = this.mouseover_colheading;
						ths[j].onmouseout  = this.mouseout_colheading;
					}
				}
			}
*/

			// row highlight to help reading data
			var tbody = tables[iTable].getElementsByTagName('tbody');
			for(i=0; i<tbody.length;i++) {
				/*if (CssClass.has(tbody[i], 'hightlight-rows')) {*/
					var trs = tbody[i].getElementsByTagName('tr');
					for (j=0;j<trs.length;j++) {
						this.attachRowEvents(trs[j]);
					}
				/*}*/
			}
		}
	},
	
	attachRowEvents: function(tr) {
		tr.onmouseover = this.mouseover_datarow;
		tr.onmouseout  = this.mouseout_datarow;
	},
	

	// separate functions to save memory and avoid "closure" leaks in IE
	mouseover_datarow:		function() { CssClass.add(this,uiTables.DATAROW_HIGHLIGHT_CLASS); },
	mouseout_datarow:		function() { CssClass.remove(this,uiTables.DATAROW_HIGHLIGHT_CLASS); },
//	mouseover_colheading: 	function() { CssClass.add(this,uiTables.COLHEADING_HIGHLIGHT_CLASS); },
//	mouseout_colheading:	function() { CssClass.remove(this,uiTables.COLHEADING_HIGHLIGHT_CLASS); }
}

myDom.addEvent(window, 'load', function(){uiTables.init()} ); 	
