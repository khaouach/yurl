

decimalIndicator = '.';
/**
* @author TSAJAS, Alex Jonk
* @date 22-06-2007
* 2 alphabetic characters + 9 alpha-numeric digits + 1 numeric digit makes a valid ISIN Code
* about regular expresions http://www.webreference.com/js/column5/index.html
**/
function isISIN(isinCode){
	var myIsin = new RegExp("[a-zA-Z][a-zA-Z]\\w\\w\\w\\w\\w\\w\\w\\w\\w\\d","i");	
	return myIsin.test(isinCode);	
}

/**
* @author TSAJAS, Alex Jonk
* @date 12-07-2007
* checks for a valid currecny mask
*/
function isCurrency(currency){
	if(currency===null) return true;
	if(currency.length===0) return true;
	var myReg = new RegExp("[A-Z]{3}","i");	
	return myReg.test(currency);	
}

/* checks if  a value is between 2 lengths */
function isMinMaxDigits(value, min ,max){
	if(value===null) return true;
	if(value.length===0) return true;
	var myReg = new RegExp("^-?\\w{" + min + "," + max + "}$");	
	return myReg.test(value);	
}

/* checks the maximum precision */
function isMaxPrecision(value, precision){
	if(value===null) return true;
	if(value.length===0) return true;
	if(precision===0){
		//since the precision equals 0 no . may be encountered
		var myReg = new RegExp("^-?\\d+\\d{0,"+ precision + "}$");
	}else{
		var myReg = new RegExp("^-?\\d+\\" + decimalIndicator + "?\\d{0,"+ precision + "}$");
	}	
	return myReg.test(value);	
}
/* uses regualar expresions to see its numeric */
function isNumeric(value){
	if(value===null) return true;
	if(value.length===0) return true;
	var expresion = "^-?\\d+\\" + decimalIndicator + "?\\d*$";
	var myReg = new RegExp(expresion);		
	console.log(myReg.test(value));
	return myReg.test(value);		
}

function isEmptyById(elementId){	
	var element = document.getElementById(elementId);
	if(!element) return true;
	if(element.value.length > 0){
		return false;
	}else{
		return true;  //its empty
	}
}

function stringEquals(elementId, value){
	
	var element = document.getElementById(elementId);
	if(!element) return true;
	if(element.value === value){
		return true;
	}else{
		return false; 
	}
}

/**
* @author unknown, modified by TSAJAS, Alex Jonk
* @date 22-06-2007
* checks for a valid date
*/
function isDate(dtStr, alertOn){
	if(dtStr===null) return true;//no date is a good date
	if(dtStr.length===0) return true; //no date is a good date
	var daysInMonth = DaysArray(12)
	var pos1=dtStr.indexOf(dtCh)
	var pos2=dtStr.indexOf(dtCh,pos1+1)
	var strDay=dtStr.substring(0,pos1)
	var strMonth=dtStr.substring(pos1+1,pos2)
	var strYear=dtStr.substring(pos2+1)
	strYr=strYear
	if (strDay.charAt(0)=="0" && strDay.length>1) strDay=strDay.substring(1)
	if (strMonth.charAt(0)=="0" && strMonth.length>1) strMonth=strMonth.substring(1)
	for (var i = 1; i <= 3; i++) {
		if (strYr.charAt(0)=="0" && strYr.length>1) strYr=strYr.substring(1)
	}
	month=parseInt(strMonth)
	day=parseInt(strDay)
	year=parseInt(strYr)
	if (pos1==-1 || pos2==-1){
		if(alertOn)alert("The date format should be : dd" + dtCh + "mm" + dtCh + "yyyy");
		return false
	}
	if (strMonth.length<1 || month<1 || month>12){
		if(alertOn)alert("Please enter a valid month");
		return false
	}
	if (strDay.length<1 || day<1 || day>31 || (month==2 && day>daysInFebruary(year)) || day > daysInMonth[month]){
		if(alertOn)alert("Please enter a valid day");
		return false
	}
	if (strYear.length != 4 || year==0 || year<minYear || year>maxYear){
		if(alertOn)	alert("Please enter a valid 4 digit year between "+minYear+" and "+maxYear);
		return false
	}
	if (dtStr.indexOf(dtCh,pos2+1)!=-1 || isInteger(stripCharsInBag(dtStr, dtCh))==false){
		if(alertOn)alert("Please enter a valid date");
		return false
	}
	return true
}