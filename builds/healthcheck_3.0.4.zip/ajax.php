<?php

/**
 * This file handles all ajax requests
 */
define('_JEXEC', getcwd());
define('JPATH_SITE', getcwd());

require_once("classes.healthcheck.php");
require_once("config.php");
require_once("database.php");


require_once('pwframework/ipwframework.php');

$command = new crudcommand();
$GLOBALS['command'] = $command;
$command->optionUrlTag = "unit";
$command->actionUrlTag = "act";

$command->preNavUrl = "index.php";


if (!(isset($_REQUEST['unit']) && isset($_REQUEST['act']))) {
    return;
}

//$command->newCommand("chart", new commandAction("main", null, false));
//$command->newCommand("data", new commandAction("detail_site", array("id", "timestamp"), false));
//$command->newCommand("data", new commandAction("table", array("timestamp"), false));
//$command->newCommand("site", new commandAction("get_health", array("site_id"), false));
//$command->newCommand("incident", new commandAction("get", array("id", "timestamp"), false));
$command->newCommand("run", new commandAction("get_last", null, false));
$command->newCommand("run", new commandAction("get_data", null, false));
$command->newCommand("run", new commandAction("get_site", array("id"), false));
$command->newCommand("run", new commandAction("site_update", array("id", "url", "url_site", "remarks"), false));

$command->run();

//function chart_main(){
//    $sites = array();
//    $sites = Database::get_stats();
//   // $sites['nok'] = Database::get_stats('nok');
//
//    echo json_encode($sites);
//}

/**
 * gets an overview of the latest run including overview of status
 */
function run_get_last() {

    $run = Database::get_run_id(null);
    $date = DateHelper::dateTimeStringFromSQL($run->timestamp);
    $status = Database::get_status_overview($run->id);
    $run->status = new stdClass();
//    print_r($status);
    if (array_key_exists(1, $status)) {
        if ($status[1]->status == "ok") {
            $run->status->nok = $status[0]->size;
            $run->status->ok = $status[1]->size;
        } else {
            $run->status->nok = $status[1]->size;
            $run->status->ok = $status[0]->size;
        }
    } else {        
        $run->status->ok = $status[0]->size;
        $run->status->nok = 0;
    }


    $run->formatted_date = $date;
    output_json($run);
}

function run_get_data() {
    $run = Database::get_run_id(null);    
    $data = Database::get_sites_data($run->id);
    
    //print_r($data);
    output_json($data);
}

function run_get_site($site_id) {
    $detail = Database::get_site($site_id);
    output_json($detail);
}

function run_site_update($site_id, $url, $url_site, $remarks) {
    $result = Database::update_site($site_id, $url, $url_site, $remarks);
    $re = new stdClass();
    $re->result = $result;
    output_json($re);
}

function output_json($data){
    header('Content-type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST');
    echo json_encode($data);
}

//function data_table($timestamp=null){ 
//    
//    if(isset($timestamp) && strlen($timestamp) > 0 ){
//        $date = new DateTime();
//        $t2 = $date->getTimestamp();
//       //$timestamp = htmlspecialchars($_REQUEST['timestamp']);
//        $t1 = Database::timestamp_from_highcharts($timestamp);
//        $date->setTimestamp($t1);
//    }else{
//        $t1 = null;
//    }
//   
//    $run = Database::get_run_id($t1);    
//    if($run==null){
//        $run = Database::get_run_id(null);    
//    }
//    $run_id = $run->id;
//    
//    $sites = Database::get_sites_data($run_id);
//    foreach($sites as $site){
//        unset($site->raw);
//        $site->version = htmlspecialchars($site->version);
//        $site->last_change  = Database::get_last_change_date($site->timestamp);          
//    }
//    //$uptimes = Database::get_uptimes();
//    $retval = new stdClass();
//    $retval->data = $sites;
//    
//    echo json_encode($retval);
//}
//
//function data_detail_site($site_id, $timestamp){
//   
//    $timestamp = Database::timestamp_from_highcharts($timestamp);
//    $detail = Database::get_site_detail($site_id, $timestamp);
//    
//    $detail->html = sprintf("<h1>Status</h1>"
//           . "<form role='form'>"
//            . "<div class='form-group'>"            
//            . "<p class='form-control-static'>%s</p></div>"
//            . "<div class='form-group'><label>Status</label>"
//            . "<p class='form-control-static' >%s</p></div>"
//            . "<div class='form-group'><label>Time</label>"
//            . "<p class='form-control-static'>%s</p></div></form>", $detail->raw, $detail->status, $detail->timestamp);
//    
//    echo json_encode($detail);
//}
//
//function site_get_health($site_id){
//    $sites = Database::get_sites(true);
//
//    $site_id =  htmlspecialchars($_REQUEST["id"]);
//
//    //print_r($sites[$site_id]);
//    $site = ($sites[$site_id]);
//    $site->id = $site_id;
//    try {
//        $data = @file_get_contents($site->url);
//        if (strpos($data, "Health check test : OK") > 1) {
//            $site->status = "ok";
//            $pos = strpos($data, "version:");
//            $site->version = substr($data, $pos, strlen($data));
//        } else {
//            $site->status = "nok";
//            $in_failure = true;
//        }
//    } catch (Exception $ex) {
//        $site->status = "nok";
//        $in_failure = true;
//    }
//
//    echo json_encode($site);
//
//}
//
//function incident_get($site_id, $timestamp){   
//    $timestamp = Database::timestamp_from_highcharts($timestamp);
//    $date = new DateTime();
//    $date->setTimestamp($timestamp);
//    $detail = Database::get_incident($site_id, $date);
//    
//    $detail->html = sprintf("<h1>Incident</h1>"
//           . "<form role='form'>"
//            . "<div class='form-group'>"
//            . "<label>Call/Incident</label>"
//            . "<p class='form-control-static'>%s</p></div>"
//            . "<div class='form-group'><label>By</label>"
//            . "<p class='form-control-static' >%s</p></div>"
//            . "<div class='form-group'><label>Remarks</label>"
//            . "<p class='form-control-static'>%s</p></div></form>", $detail->call_im, $detail->by, $detail->remarks);
//    
//    echo json_encode($detail);
//}
