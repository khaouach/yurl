var storyboardControllers = angular.module('storyboardControllers', []);

storyboardControllers.controller('ItemListCtrl', ['$scope','$http', '$interval', 'Sites',
    function ($scope,$http, $interval, Sites) {
        
        $interval(function () {
            Sites.getLastRun(function(run){
                console.log('checking for new data');
                if(run.id !== $scope.last_run.id){
                    //only update when there is a new run
                    $scope.items = Sites.list();
                    $scope.last_run = run;
                }else{
                    return false;
                }

                console.log('refreshing');
            });
            
            
            
        }, refreshRate);

        $scope.items = Sites.list();

        $scope.last_run = Sites.getLastRun();

        

        $scope.orderProp = 'status';

        //event that is bound to ng-click, just for a demo 
        $scope.show = function () {
            console.log('who');
        };        
        
    }]);

storyboardControllers.controller('ItemDetailCtrl', ['$scope', 'Sites', '$routeParams',
    function ($scope, Sites, $routeParams) {
        $routeParams.itemId;
        $scope.item = Sites.get({id: $routeParams.itemId});

        var barclass = "progress-bar-success";
        if ($scope.item.uptime < 60) {
            barclass = "progress-bar-danger";
        } else if ($scope.item.uptime < 70) {
            barclass = "progress-bar-warning";
        } else if ($scope.item.uptime < 80) {
            barclass = "progress-bar-info";
        } 
        
        $scope.bar_class = barclass;
        
        $scope.save = function(){
            console.log('saving.');            
            Sites.update({
                id: $routeParams.itemId
                , url : $scope.item.url
                , url_site : $scope.item.url_site
                , remarks : $scope.item.remarks
            }, function(data){                
                if(data.result===true){
                    bootbox.alert("Save was successful");
                }
            });
        };
    }
]);


