<?php
/** 
 * @package		PWFramework
 * @author    	Pageworks http://www.pageworks.nl
 * @copyright	Copyright (c) 2006 - 2010 Pageworks. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

 
 // Import library dependencies
$PW_LOCATION = "/pwframework/PWFramework";
$PW_PATH = JPATH_SITE . $PW_LOCATION;


/*loading required classes and libraries */
loadIfClassExistence( $PW_PATH . "/classes/class.command.php");
loadIfClassExistence( $PW_PATH . "/classes/class.element.php");			
//loadIfClassExistence( $PW_PATH . "/classes/class.column.php");		
//loadIfClassExistence( $PW_PATH . "/classes/class.table.php");
//loadIfClassExistence( $PW_PATH . "/classes/class.dbtable.php");
loadIfClassExistence( $PW_PATH . "/classes/class.form.php");
//loadIfClassExistence( $PW_PATH . "/classes/class.pager.php");
//loadIfClassExistence( $PW_PATH . "/classes/class.tablefilter.php");
//loadIfClassExistence( $PW_PATH . "/classes/class.menu.php");
loadIfClassExistence( $PW_PATH . "/lib/common.php");


function getReqParamVal($name){
	if(isset($_REQUEST[$name])){
		return $_REQUEST[$name];
	}else{
		return null;
	}
}		
	
function redirect($url){
	?>
	<script language="JavaScript">
	<!--
	 window.location="<?php echo $url?>";
	//-->
	</script>
	<?php
}	
		
function loadIfClassExistence($file){
	if(file_exists($file)){
		require_once($file);
	}else{
		echo "Unable to load class with in file :" . $file . " because it does not exist, continueing happily";
	}

}