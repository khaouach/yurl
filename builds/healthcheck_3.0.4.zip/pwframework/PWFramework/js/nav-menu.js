/*********************************************************************************
*	Toolbar 
*	de beheerder van alle items en subItems
* 	Author Alex Jonk, 2007
**********************************************************************************/

var toolbarItemIndex  = 0; //last selected item

function Toolbar(){
	this.toolbarItems = new Array();
	this.addItem = toolbar_addItem;
	this.render = toolbar_render;
}

/* adding the subitem OBJECTS */
function toolbar_addItem(item){
	this.toolbarItems.push(item);
}

/* toolbar rendering */
function toolbar_render(){
	docw('<div id="cstp-header-menu" class="navigation dark-blue">');
	docw('<ul>');
	for(i=0 ; i < this.toolbarItems.length ; i++){
		if(toolbarItemIndex === i ){
			docw('<li class="active">');
		}else{
			docw('<li>');
		}
		//onclick="tClick(\'' + myObj.url + '\',' + i + ');"
		var myObj = this.toolbarItems[i];         
        docw('<a rel="dropmenu' + i + '" class="wpsSelectedPlaceLink" href="' + myObj.url  + '?navMenuItem=' + i + '">' + myObj.name + '</a>');
        docw('</li>');
    }
	docw('</ul><div class="clearer"></div></div>');
	
	/* rendering the submenu Items */
	var item;
	for(i=0 ; i < this.toolbarItems.length ; i++){	
		item = this.toolbarItems[i];
		renderSubItems('dropmenu' + i, item.subItems, i);		
	}
	
}

function renderSubItems(relation, subItems, masterIndex){
	docw('<div id="' + relation + '" class="dropmenudiv level1">');
	docw('<table cellspacing="1">');
	var item;
	for(j=0; j < subItems.length; j++){
		item = subItems[j];
		docw('<tr><td><a href="' + item.url + '?navMenuItem=' + masterIndex+ '">' + item.name +  '</a></td></tr>');
	}	
	docw('</table>');
	docw('</div>');
}



/*********************************************************************************
*	Toolbar menu Item
*	deze wordt geplaats op de toolbar
**********************************************************************************/

function ToolbarItem(name, url){
	this.subItems = new Array();
	this.name = name;	
	this.url = url;
	//referal to addSubItem function;
	this.addSubItem = toolbarItem_AddToolbarSubItem;
}

/* adding subitems to the toolbarItem */
function toolbarItem_AddToolbarSubItem(name, url){
	this.subItems.push(new ToolbarSubItem(name, url));
}

/*********************************************************************************
*	Toolbar subitems
* 	 wordt geplaats op een toolbarItem
**********************************************************************************/

function ToolbarSubItem(name, url){
	this.name = name;
	this.url = url;	
}

/*********************************************************************************
*	common functions
**********************************************************************************/

function docw(text){
    document.writeln(text);
}

function tClick(url, itemIndex){
	toolbarItemIndex = itemIndex;
	window.location.href = url;
}

/*********************************************************************************
*	example
**********************************************************************************/
/*
bar = new Toolbar();

itemCorpAct = new ToolbarItem("Corporate Actions", null);
itemIssues = new ToolbarItem("Issues", null);
itemUpload = new ToolbarItem("Upload", null);
itemReport = new ToolbarItem("Reports", null);
itemExport = new ToolbarItem("Export", null);

bar.addItem(itemCorpAct);
bar.addItem(itemIssues);
bar.addItem(itemUpload);
bar.addItem(itemReport);
bar.addItem(itemExport);

bar.render();
*/
