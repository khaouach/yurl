/*
	toolbox.js - utility functions
	fde/emakina 2006
*/

/* dom utility */

// getElement(s)ById()
function $$() {
	var elements = new Array();
	
	for (var i = 0; i < arguments.length; i++) {
		var element = arguments[i];
		if (typeof element == 'string')
			element = document.getElementById(element);
		
		if (arguments.length == 1)
			return element;
	
		elements.push(element);
	}
	
	return elements;
}

var myDom = {
	// nodetypes
	ELEMENT_NODE:1,	ATTRIBUTE_NODE:2, TEXT_NODE:3,
	
	// crossbrowser addEvent
	addEvent: function(obj, evType, fn, useCapture) {
		if (useCapture==undefined)
			useCapture = false; // use bubbling
		if (obj.addEventListener){
			obj.addEventListener(evType, fn, useCapture);
			return true;
		} else if (obj.attachEvent){
			var r = obj.attachEvent("on"+evType, fn);
			return r;
		} else {
			alert("Handler could not be attached");
		}
	},

	// crossbrowser removeEvent
	removeEvent: function(obj, evType, fn, useCapture) {
		if (useCapture==undefined)
			useCapture = false; // use bubbling
		if (obj.removeEventListener){
			obj.removeEventListener(evType, fn, useCapture);
			return true;
		} else if (obj.detachEvent){
			var r = obj.detachEvent("on"+evType, fn);
			return r;
		} else {
			alert("Handler could not be removed");
		}
	},
	
	// returns an array of elements children of oElm, of given tag and having given class
	getElementsByClassName: function (oElm, strTagName, strClassName){
	    var arrElements = (strTagName == "*" && oElm.all)? oElm.all : oElm.getElementsByTagName(strTagName);
	    var arrReturnElements = new Array();
	    strClassName = strClassName.replace(/\-/g, "\\-");
	    var oRegExp = new RegExp("(^|\\s)" + strClassName + "(\\s|$)");
	    var oElement;
	    for(var i=0; i<arrElements.length; i++){
	        oElement = arrElements[i];      
	        if(oRegExp.test(oElement.className)){
	            arrReturnElements.push(oElement);
	        }   
	    }
	    return (arrReturnElements)
	},
	
	// returns parent html element of given tag, or null if not found
	getParent: function(el, sTagName)
	{
		if (el == null) {
			return null;
		}
		// gecko bug, supposed to be uppercase
		else if (el.nodeType == myDom.ELEMENT_NODE && el.tagName.toLowerCase()==sTagName)
		{
			return el;
		}else{
			return myDom.getParent(el.parentNode, sTagName);
		}
	},
	
	findPosition: function(oLink) {
		if (oLink.offsetParent){
			for (var posX = 0, posY = 0; oLink.offsetParent; oLink = oLink.offsetParent){
				posX += oLink.offsetLeft;
				posY += oLink.offsetTop;
			}
			return [posX, posY];
		}else{
			return [oLink.x, oLink.y];
		}
	}	
}


var CssClass = {
	classnames: function(element) {
		return element.className.split(/\s+/);
	},
	
	set: function(element, s) {
		element.className = s;
	},
	
	add: function(element, s) {
		if (this.has(element,s)) return;// minimize refresh (for buggy IE)
		
		var classes = this.classnames(element);
		for (var i=0;i<classes.length;i++) {
			if (classes[i]=='s') return;
		}
		var newclasses = classes.concat(s).join(' ');
		element.className = newclasses;
	},
	
	has: function(element, s) {
		var classes = this.classnames(element);
		for (var i=0;i<classes.length;i++) {
			if (classes[i]==s) {
				return true;
			}
		}
		return false;
	},

	remove: function(element, s) {
		if (!this.has(element,s)) return;// minimize refresh (for buggy IE)
		
		var classes = this.classnames(element);
		var newclasses = '';
		for (var i=0;i<classes.length;i++) {
			if (classes[i]!=s) {
				newclasses += (i>0?' ':'')+classes[i];
			}
		}
		element.className = newclasses;
	},

	replace: function(element, sold, snew) {
		var classes = this.classnames(element);
		var newclasses = '';
		for (var i=0;i<classes.length;i++) {
			if (classes[i]!=sold) {
				newclasses += (i>0?' ':'')+classes[i];
			}
		}
		element.className = newclasses+' '+snew;
	}
}


/* cookies */

var cookies = {
	
	create: function(name,value,days) {
		if (days) {
			var date = new Date();
			date.setTime(date.getTime()+(days*24*60*60*1000));
			var expires = "; expires="+date.toGMTString();
		}
		else {
			expires = "";
		}
		document.cookie = name+"="+value+expires+"; path=/";
	},

	read: function(name) {
		var nameEQ = name + "=";
		var ca = document.cookie.split(';');
		for(var i=0;i < ca.length;i++) {
			var c = ca[i];
			while (c.charAt(0)==' ') {
				c = c.substring(1,c.length);
			}
			if (c.indexOf(nameEQ) == 0) {
				return c.substring(nameEQ.length,c.length);
			}
		}
		return null;
	}
}


/* font resizing */

var fontSize = {
	
	currentsize:11, minsizepx:8, maxsizepx:15, cookie_duration_days:1,
	
	getDefaultSize: function() { return 11; },
	
	setActiveSize: function(n) {
		if (!document.getElementsByTagName) return;
		var b = document.getElementsByTagName('body')[0];
		b.style.fontSize = n+'px';
	},
	
	changeSize: function (n){
		this.currentsize = this.currentsize + n;
		if(this.currentsize>this.maxsizepx){this.currentsize=this.maxsizepx;}else if(this.currentsize<this.minsizepx){this.currentsize=this.minsizepx;}
		this.setActiveSize(this.currentsize);
		this.saveSize();
	},
	
	loadSize: function() {
		var cookie = cookies.read("fontsize");
		this.currentsize = cookie ? parseInt(cookie) : this.getDefaultSize();
		if (this.currentsize == 'null')
			this.currentsize = this.getDefaultSize();
		if (this.currentsize != this.getDefaultSize())
			this.setActiveSize(this.currentsize);
	},
	
	saveSize: function() {
		cookies.create("fontsize", this.currentsize, this.cookie_duration_days);
	}
}


/* testing (this part can be removed) */

var KT_CONSOLE_ENABLED = false;
var KT_CONSOLE_ID = 'DBGConsole_DEBUG';

function DBGConsole() {	this.debugCounter = 0; }
DBGConsole.prototype.log = function(message)
{
	if (!KT_CONSOLE_ENABLED) return;
    this.debugCounter++;

	var found = !!document.getElementById(KT_CONSOLE_ID);
	if (!found) {
		// create the debugging div
		d = document.createElement('div');
		d.id = KT_CONSOLE_ID;
		d.style.border = '2px solid #dc0000';
		d.style.background = '#fff5f5';
		d.style.padding = '5px';
		d.style.font = 'bold 10px Verdana;';
		d.style.textAlign = 'left';
		d.style.color = '#000';
		d.style.font = '12px Courier New, monospace;';
	}
	var t = document.createTextNode(''+this.debugCounter + ': ' + message);
    var br = document.createElement('br');
	d.appendChild(t);
    d.appendChild(br);
	if (!found) {
		document.getElementsByTagName('body')[0].appendChild(d);
	}
}

if (!console || (!KT_CONSOLE_ENABLED && console.log && console.assert) ) {
	var console = new DBGConsole();
}
