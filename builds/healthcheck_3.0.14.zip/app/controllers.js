var storyboardControllers = angular.module('storyboardControllers', []);

storyboardControllers.controller('ItemListCtrl', ['$scope','$http', '$interval', 'Sites',
    function ($scope,$http, $interval, Sites) {
        
        //defaulting paging settings
        $scope.currentPage = 0;
        $scope.pageSize = 20;
        //set default order status
        $scope.orderProp = 'status.status';
        
        $interval(function () {
            Sites.getLastRun(function(run){
                console.log('checking for new data');
                if(run.id !== $scope.last_run.id){
                    //only update when there is a new run
                    $scope.items = Sites.list();
                    $scope.last_run = run;
                }else{
                    return false;
                }

                console.log('refreshing');
            });
            
            
            
        }, refreshRate);
            
        //inital load of items
        Sites.list(function(items){
            $scope.items = items;            
        });
        
        //controller function :: adding paging for more details look here http://jsfiddle.net/2ZzZB/56/
        $scope.numberOfPages=function(){
            if($scope.items===null || $scope.items===undefined){
                return 0;
            }else{
                return Math.ceil($scope.items.length/$scope.pageSize);                                
            }

        };
        
        //controller function :: 
        $scope.siteInDialog = function(site, url_site){
            var url = site.url;
            if(url_site){
                var url = site.url_site;
            }
            var sWidth = $(window).width();
            var sHeight = $(window).height();
            var title = '<i class="fa fa-globe fa-2x" ></i> ' + site.application + ' - ' + site.environment + ' - ' + site.type + ' - ' + site.version;
            
            var html = '<iframe width="100%" height="' + (sHeight * 0.7)+ '" frameborder="0"  scrolling="n"  allowTransparency="false" src="' + url + '" ></iframe>';
            $('#site-modal .modal-dialog').width(sWidth * 0.8);
            $('#site-modal .modal-title').html(title);
            $('#site-modal .modal-body').html(html);
            $('#site-modal #remarks').html(site.remarks);
            $('#site-modal').modal('show');
        };

        //initial latest run information
        $scope.last_run = Sites.getLastRun();        
        
    }]);

storyboardControllers.controller('ItemDetailCtrl', ['$scope','$location', 'Sites', '$routeParams',
    function ($scope, $location, Sites, $routeParams) {
        $routeParams.itemId;
        $scope.item = Sites.get({id: $routeParams.itemId});

        var barclass = "progress-bar-success";
        if ($scope.item.uptime < 60) {
            barclass = "progress-bar-danger";
        } else if ($scope.item.uptime < 70) {
            barclass = "progress-bar-warning";
        } else if ($scope.item.uptime < 80) {
            barclass = "progress-bar-info";
        } 
        
        $scope.bar_class = barclass;
        
        $scope.save = function(){
            console.log('saving.');            
            Sites.update({
                id: $routeParams.itemId
                , url : $scope.item.url
                , url_site : $scope.item.url_site
                , remarks : $scope.item.remarks
            }, function(data){                
                if(data.result===true){
                    bootbox.alert("Save was successful");
                }
            });
        };
        
        $scope.delete = function(){
            bootbox.confirm('Are you sure', function(result){
                if(result){
                    Sites.remove({id: $routeParams.itemId}, function(r){
                        if(r.result){
                            $location.path('/items');
                        }else{
                            bootbox.alert('Delete failed');
                        }
                        
                    });
                    
                }
            });
        };
    }
]);


