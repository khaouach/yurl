<?php

defined('_JEXEC') or die('Restricted access');

class Database {

    private static $mysqli;
    public static $DATE_FORMAT = "d-m-Y H:i:s";
    public static $DATE_SQL_FORMAT = "Y-m-d H:i:s";

    //inits db if first time and returns connection handle 
    static function init() {
        //Create connection
        if (self::$mysqli == null) {
            self::$mysqli = new mysqli(
                    Config::$host
                    , Config::$user
                    , Config::$password
                    , Config::$db);

            //Check connection
            if (mysqli_connect_errno(self::$mysqli)) {
                echo "Error: Failed to connect to MySQL: " . mysqli_connect_error();
                echo "host" . Config::$host;
                die();
            }
        }

        return self::$mysqli;
    }

    static function closeDbo() {
        mysqli_close(self::init());
    }

    private static function loadObjectList($sql) {
        self::init();
        $result = mysqli_query(self::$mysqli, $sql);
        $sites = array();
        if ($result) {

            while ($row = mysqli_fetch_object($result)) {
                $sites[] = $row;
            }
        }


        return $sites;
    }

    private static function loadObject($sql) {
        $sites = self::loadObjectList($sql);
        return $sites[0];
    }

    private static function loadResult($sql) {
        self::init();
        $result = mysqli_query(self::$mysqli, $sql);
        if ($result) {
            $field = mysqli_fetch_field($result);
            $row = mysqli_fetch_assoc($result);
            $value = $row[$field->name];
              
        }
        return $value;
    }

    static function query($sql, $classObject) {
        $result = mysqli_query(self::$mysqli, $sql);

        while ($row = mysqli_fetch_array($result)) {
            echo $row['FirstName'] . " " . $row['LastName'];
            echo "<br>";
        }
    }

    static function get_run_id($timestamp) {
        if ($timestamp == null) {
            $select = "select * from runs where id = (select max(id) from runs)";
        } else {
            $select = sprintf("select * from runs where UNIX_TIMESTAMP(timestamp) = %d ", $timestamp);
        }
        
        $result =  self::loadObject($select);

        return $result;
    }

    static function get_status_overview($run_id) {
        $select = self::get_sql_sitedata($run_id);
        $sql = sprintf("select status, count(status) as size from (%s) as statuses group by status ", $select);
        $sites = self::loadObjectList($sql);
        
        return $sites;
    }

    public static function get_changes_over_days($days) {
        $sql = sprintf("select count(1) as amount from run_statuses where timestamp > (NOW() - INTERVAL %d DAY)", $days);
        $result = self::loadResult($sql);
        return $result;
    }

    private static function get_sql_sitedata($run_id) {
        $select = sprintf("select st.site_id, ls.run_id, st.status, st.http_code, st.id as status_id, st.raw, r.`timestamp`, s.environment, s.url, s.url_site , s.application, s.`type`, s.remarks from statuses st 
                        join (
                            select `statuses`.`site_id` AS `site_id`,max(`statuses`.`run_id`) AS `run_id` from `statuses` where run_id <= %d group by `statuses`.`site_id`
                            ) ls on st.run_id = ls.run_id and st.site_id = ls.site_id
                                                        join runs r on r.id = st.run_id
                                                        join sites s on s.id = st.site_id
                                                        order by st.status, r.`timestamp` desc", $run_id);
        return $select;
    }

    static function get_sites_data($run_id) {
//        self::init();
        //if ($run_id == null) {
        $select = self::get_sql_sitedata($run_id);

//        echo $select;
//        $result = mysqli_query(self::$mysqli, $select);
//        $select =  sprintf("select * from run_statuses where run_id = %d", $run_id);
        $results = self::loadObjectList($select);  
//        sysout($select);

        if ($results) {
            $sites = array();
            foreach ($results as $row) {          
                $status = Parser::parse_raw_data($row->raw);                
                $row->status = $status;
                $row->timestamp = DateHelper::dateTimeStringFromSQL($row->timestamp);
                $sites[] = $row;
            }

            
        }
        return $sites;
    }

    /**
     * get all sites
     * @return type
     */
    static function get_sites() {
        self::init();
        //if ($run_id == null) {
        $select = sprintf("select *, id as site_id from sites;");

        $sites = self::loadObjectList($select);
        return $sites;
    }

    /**
     * Called by deamon
     * @param type $status
     * @return type
     */
    static function insert_site_status($status) {
        self::init();
        $select = sprintf("insert into statuses (site_id, raw, status, run_id, http_code) values (%d, '%s', '%s', %d, '%s') ; "
                , $status->site_id, $status->raw, $status->status, $status->run_id, $status->http_code);
        $retval = mysqli_query(self::$mysqli, $select);
        return $retval;
    }

    /**
     * Called by deamon
     * @param type $datetime
     * @return type
     */
    static function insert_run($datetime) {
        self::init();
        $select = sprintf("insert into runs (timestamp) values ('%s');", $datetime->format('Y-m-d H:i:s'));
        mysqli_query(self::$mysqli, $select);
        $retval = self::$mysqli->insert_id;
        return $retval;
    }

    /**
     * Called by deamon
     * @param type $site_id
     * @return \Site
     */
    static function get_latest_status_for_site($site_id) {
        self::init();
        $select = sprintf(" select * from statuses s
            left join runs r on r.id = s.run_id
            where s.id = (select max(s2.id)  from statuses s2 where site_id =%d)", $site_id);
        $results = self::loadObjectList($select);
        if (count($results) > 0) {
            return $results[0];
        } else {
            $site = new Site();
            $site->raw = null;
            return $site;
        }
    }

    /**
     * returns all information about a site
     * @param type $id
     * @return type
     */
    static function get_site($id) {
        $selectSites = sprintf("select * from sites where id  = %d ", $id);
        $site = self::loadObject($selectSites);


    
        $selectStatuses = sprintf("select * from statuses s left join runs r on r.id = s.run_id where s.site_id = %d order by timestamp desc limit 0, 30", $id);
        $results = self::loadObjectList($selectStatuses);
        if ($results) {
            $site->runs = array();
            foreach ($results as $row) {
                $status = Parser::parse_raw_data($row->raw);
                $row->timestamp = DateHelper::dateTimeStringFromSQL($row->timestamp);
                $row->version = $status->version;
                $site->runs[] = $row;
            }
        }

        /** incidents * */
//        $site->incidents = array();
//        $selectIncidents = sprintf("select *, UNIX_TIMESTAMP(timestamp) as unixtime from incidents where site_id = %d and timestamp >= DATE_ADD(CURDATE(), INTERVAL -14 DAY) ", $id);
//        $incedents = self::loadObjectList($selectIncidents);
//        if($results){
//            foreach ($incedents as $row) {
//                
//            }
//            $site->incidents[] = array(intval($row->unixtime) * 1000 + (1000 * 60 * 60 * 2), 0.5);
//        }

        $site->uptime = self::get_site_uptime($id);

        return $site;
    }

    static function update_site($id, $url, $url_site, $remarks) {
        self::init();
        $update = sprintf("update sites s set url = '%s', url_site = '%s', remarks='%s'  where s.id = %d", $url, $url_site, $remarks, $id);
        $result = mysqli_query(self::$mysqli, $update);
        return $result;
    }

    /**
     * calculates up time of a site
     * @param type $site_id
     * @return type
     */
    static function get_site_uptime($site_id) {
        self::init();
        $select = sprintf("select UNIX_TIMESTAMP(timestamp) , status from run_statuses where 
                        site_id = %d order by timestamp ", $site_id);
        //. " and timestamp >= DATE_ADD(CURDATE(), INTERVAL -14 DAY)" 
        //. "order by timestamp  ";

        $result = mysqli_query(self::$mysqli, $select);

        return 100;
    }


}
