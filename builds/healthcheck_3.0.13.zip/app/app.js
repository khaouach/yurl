(function () {

   var storyboardApp = angular.module('storyboardApp', [ 
       'ngRoute',
       'storyboardAnimations',
       'storyboardServices',
       'storyboardControllers']);

    storyboardApp.config(['$routeProvider',
        function ($routeProvider) {
            $routeProvider.
                    when('/items', {
                        templateUrl: 'app/partials/main-overview.html',
                        controller: 'ItemListCtrl'
                    }).
                    when('/items/:itemId', {
                        templateUrl: 'app/partials/item-details.html',
                        controller: 'ItemDetailCtrl'
                    }).
                    otherwise({
                        redirectTo: '/items'
                    });
        }]);
  

})();