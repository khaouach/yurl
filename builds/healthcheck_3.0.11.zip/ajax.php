<?php

/**
 * This file handles all ajax requests
 */
define('_JEXEC', getcwd());
define('JPATH_SITE', getcwd());

require_once("classes.healthcheck.php");
require_once("config.php");
require_once("database.php");


require_once('pwframework/ipwframework.php');

$pwcommand = PWFrameWorks::getCommand();

//turn on debugging
//$pwcommand->debug(true);

$pwcommand->unit("run")->action("get_last");
$pwcommand->unit("run")->action("get_data");
$pwcommand->unit("run")->action("get_site")->param("id");
$pwcommand->unit("run")->action("site_update")->param("id")->param("url")->param("url_site")->param("remarks");

if (!(isset($_REQUEST['unit']) && isset($_REQUEST['act']))) {
    return;
}

class PWTaskRun extends PWController {
/**
 * gets an overview of the latest run including overview of status
 */
    public function get_last() {

        $run = Database::get_run_id(null);
        $date = DateHelper::dateTimeStringFromSQL($run->timestamp);
        $status = Database::get_status_overview($run->id);
        $run->status = new stdClass();
    //    print_r($status);
        if (array_key_exists(1, $status)) {
            if ($status[1]->status == "ok") {
                $run->status->nok = $status[0]->size;
                $run->status->ok = $status[1]->size;
            } else {
                $run->status->nok = $status[1]->size;
                $run->status->ok = $status[0]->size;
            }
        } else {        
            $run->status->ok = $status[0]->size;
            $run->status->nok = 0;
        }


        $run->formatted_date = $date;
        $this->output_json($run);
    }

    function get_data() {
        $run = Database::get_run_id(null);    
        $data = Database::get_sites_data($run->id);

        //print_r($data);
        $this->output_json($data);
    }

    function get_site($site_id) {
        $detail = Database::get_site($site_id);
        $this->output_json($detail);
    }

    function site_update($site_id, $url, $url_site, $remarks) {
        $result = Database::update_site($site_id, $url, $url_site, $remarks);
        $re = new stdClass();
        $re->result = $result;
        $this->output_json($re);
    }

    private function output_json($data){
        header('Content-type: application/json');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST');
        echo json_encode($data);
    }
}


$pwcommand->run();