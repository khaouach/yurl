<?php
/** 
 * @package		PWFramework
 * @author    	Pageworks http://www.pageworks.nl
 * @copyright	Copyright (c) 2006 - 2010 Pageworks. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

/*checks if a string is filled*/

if(!(defined('_VALID_MOS') || defined( '_JEXEC' ))){
	die( 'Restricted access' );
}

function isNotEmpty($string){
	if(strlen($string) > 0) return true;
}

/*checks if a string is empty */
function isEmpty($string){
	if(strlen($string) == 0) return true;
}


/**
 * converts  an array of objects to a regualar array contains a value and identifier'
 * $obj1->id = "1234"
 * $obj1->name ="Jhon Doe"
 *
 * $obj2->id = "4567"
 * $obj2->name ="Jan Smit"
 *
 * $l[] $objl;
 * $l[] $obj2;
 *
 * $arr = obj_to_arr($l,"id","name");
 *
 * @param unknown_type $objArr an array containing objects
 * @param unknown_type $key
 * @param unknown_type $val
 * @return unknown
 */
function obj_to_arr($objArr, $key, $val){
	$retval = array();
	foreach($objArr as $elem){
		$retval [$elem->{$key}] = $elem->{$val};
	}
	return $retval;
}

/**
 * converts  an array of objects to a regualar array contains a value and identifier'
 * $obj1->id = "1234"
 * $obj1->name ="Jhon Doe"
 *
 * $obj2->id = "4567"
 * $obj2->name ="Jan Smit"
 *
 * $l[] $objl;
 * $l[] $obj2;
 *
 * $arr = obj_to_arr($l,"id","name");
 *
 * @param unknown_type $objArr an array containing objects
 * @param unknown_type $param the parameter $obj->param you want to copy to the array
 * @return unknown
 */
function obj_to_arr_no_key($objArr, $param){
	$retval = array();
	foreach($objArr as $elem){
		$retval[] = $elem->{$param};
	}
	return $retval;
}

/**
 *Push an element at the beginning of an array:
 *reverse push 
 */ 

function array_rpush(&$arr, $item){
  $arr = array_pad($arr, -(count($arr) + 1), $item);
}


/**
 * gets the current page url 
 * addded on 14.03.2010
 */

function curPageURL() {
	$pageURL = 'http';
	if(isset($_SERVER["HTTPS"]))
		if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
	$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80") {
		$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	} else {
		$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	}
	return $pageURL;
}



/**
 * Returns true if the occurence if the needle is within the haystack
 *
 * @param unknown_type $haystack
 * @param unknown_type $needle
 * @return unknown
 */
function instr($haystack, $needle){
	if(stristr($haystack, $needle)===false){
		return false;	
	}else{
		return true;
	}
	
}

/**
 * returns the appropiate concat charachter based upon the current url
 * if the url contains index.php?blabla it returns & else it returns ?
 *
 * @param unknown_type $url
 * @return unknown
 */
function urlGlue($url){
	if(instr($url, "?")) {
		return "&";
	}else{
		return  "?";
	}
}
	
/**
 * fixes the end of an url with a slash of the end of it
 *
 * @param unknown_type $url
 * @return unknown
 */
function urlSlashAtEnd($url){
	$length = strlen($url);
	if(!strEndsWith($url,"/")){
		return $url . "/";
	}else{
		return $url;
	}
}


/**
 * @return bool Wether or not the given string $str starts with the givens tring $start.
 */
function strStartsWith($str, $start) {
	return substr($str, 0, strlen($start)) == $start;
}


/**
 * @return bool Wether or not the given string $str ends with the givens tring $start.
 */
function strEndsWith($str, $end) {
	return substr($str, -strlen($end), strlen($end)) == $end;
}


function strleft($s1, $s2) {
    return substr($s1, 0, strpos($s1, $s2));
} 

/**
 * functie voor debug doeleinde, niet gebruiken in productie omgeving!
 * @author Alex Jonk
 */
function sysout($obj, $die = false) {
    if (is_object($obj) || is_array($obj)) {
        $outp = print_r($obj, true);
    } else {
        $outp = $obj;
    }
    printf("<pre>%s</pre>", $outp);
    if ($die) {
        $callers = debug_backtrace();
        echo "died on method/function : " . $callers[1]['function'];
        die();
    }
}