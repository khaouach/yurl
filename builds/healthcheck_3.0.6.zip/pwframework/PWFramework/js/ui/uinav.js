/* author fde/emakina */

var uiNav = {

	cssjs: {
		SITENAV: 'cstp-header-menu',	// #id of level 0 nav.
		NAVCONTAINER: 'cstp-header-main',	// #id of container with 'position:relative' (if any)
		SUBMENUITEM: 'submenu',			// CSS class for menu item with child menus
		SUBMENUITEM_ON: 'submenufocus'	// CSS class for menu item with child menus, active
	},
	
	containerpos: null,
	delayhide: null,
	menulayer: [null,null,null,null,null],
	menufocus: [null,null,null,null,null],
	MAXLEVEL:5,

	initialize: function(sNavId) {
		// get offsets from relative positioned container, if any
		if (uiNav.cssjs.NAVCONTAINER) {
			this.containerpos = myDom.findPosition($(uiNav.cssjs.NAVCONTAINER));
		} else {
			this.containerpos = [0,0];
		}

		var oNav = $(sNavId);
		this.attach(oNav);
		
	},

	// attach navigation events
	attach: function(oParent) {		
		var oas = oParent.getElementsByTagName('a');
		var i;
		for (i=0;i<oas.length;i++) {
			var oA = oas[i];
			oA.onmouseover = uiNav.mouseover;
			oA.onmouseout = uiNav.mouseout;
			// add the arrow icon to menu items with children
			if (this.getsubmenu(oA)) {
				oA.className = uiNav.cssjs.SUBMENUITEM;
			}
		}
	},
	
	// get the navigation level, 0 = root menu bar
	getlevel: function(oA) {
		var parentDiv = myDom.getParent(oA,'div');		
		if ( /level1/.test(parentDiv.className) )
			return 1;
		else if ( /level2/.test(parentDiv.className) )
			return 2;
		else if ( /level3/.test(parentDiv.className) )
			return 3;
		return 0;
	},

	getsubmenu: function(oA) {
		var sLayerId = oA.getAttribute("rel");
		if (sLayerId) {
			return $(sLayerId);
		}
		return null;
	},

	mouseover:function() { uiNav.mouseover_f(this);	},
	mouseover_f:function(oA) {
		
		var iLevel = this.getlevel(oA);
		var oSubLayer = this.getsubmenu(oA);

		// cancel menu out
		if (this.delayhide) {
			clearTimeout(this.delayhide);
			this.delayhide = null;
		}
		
		// drop submenus that lost focus,
		//  if there is a submenu and the submenu didn't change (another dropdown), then maintain it
		var hidefrom = iLevel+1;
		if (oSubLayer && oSubLayer==this.menulayer[hidefrom])
			hidefrom++; // maintain the submenu if any
		this.hide(hidefrom);

		// clear previous submenu focus if any
		if (this.menufocus[iLevel] && this.menufocus[iLevel]!=oA) {
			this.menufocus[iLevel].className = uiNav.cssjs.SUBMENUITEM;
		}

		// open a sub menu ?
		if (oSubLayer) {
			
			// set submenu focus
			oA.className = uiNav.cssjs.SUBMENUITEM_ON;
			this.menufocus[iLevel] = oA;
			
			// clear submenu's last submenu focus if any
			if (this.menufocus[iLevel+1]) {
				this.menufocus[iLevel+1].className = uiNav.cssjs.SUBMENUITEM;
				this.menufocus[iLevel+1] = null;
			}
			
			// position submenu down if root level, or to the side
			if (iLevel<1) {
				var oLI = myDom.getParent(oA,'li');
				var pos = myDom.findPosition(oLI);
				var oUL = myDom.getParent(oA,'ul');
				var posUL = myDom.findPosition(oUL);
				pos[0] = pos[0]-posUL[0]; //-this.containerpos[0];
				pos[1] = pos[1]-this.containerpos[1]+oLI.offsetHeight;
			
				// increase dropdown width if it is shorter than the top menu item width
				if(oSubLayer.offsetWidth < oLI.offsetWidth) {
					oSubLayer.style.width = oLI.offsetWidth+'px';
					oSubLayer.getElementsByTagName('table')[0].style.width = '100%';
				}
			
			} else {
				// ie/fox correct offset from the UL (!?!?!?)			
				var oUL = $(uiNav.cssjs.NAVCONTAINER).getElementsByTagName('ul')[0];
				var posUL = myDom.findPosition(oUL);
				var oTABLE = myDom.getParent(oA,'table');
				var pos = myDom.findPosition(myDom.getParent(oA,'td'));
				// position sub menu a little bit overlap & down
				pos[0] = pos[0]-posUL[0]+oTABLE.offsetWidth-4;
				pos[1] = pos[1]-this.containerpos[1]+1;
			}
			uiNav.attach(oSubLayer);
			uiNav.displayLayer(oSubLayer, pos, iLevel+1);
		}

	},
	
	mouseout:function() { uiNav.mouseout_f(this); },
	mouseout_f:function(oA) {
		var iLevel = this.getlevel(oA);
		if (!uiNav.delayhide) {
			this.delayhide = setTimeout("uiNav.delayedhide()", 500);//msec
		} else {
			console.log('mouseout > delayhide already set!');
		}
	},
	

	// pos = [x, y]
	displayLayer: function(oLayer, pos, iLevel) {
		oLayer.style.left = pos[0]+'px';
		oLayer.style.top = pos[1]+'px';
		oLayer.style.position = 'absolute';
		oLayer.style.display = 'block';
		oLayer.style.visibility = 'visible';
		this.menulayer[iLevel] = oLayer;
	},

	delayedhide:function() {
		this.hide(1);
		this.delayhide = null;
	},

	// hide menu and its children starting from given level
	hide: function(iLevel) {
		var i;
		for (i=iLevel;i<this.MAXLEVEL;i++)
		{
			var oLayer = this.menulayer[i];
			if (oLayer) {
				oLayer.style.visibility = 'hidden';
				this.menulayer[i] = null;
			}
		}
		// clear the focus on the menu head		
		if (iLevel<=1) {
			if (this.menufocus[0]) {
				this.menufocus[0].className = '';
			}
		}
	}
}

myDom.addEvent(window, 'load', function(){uiNav.initialize(uiNav.cssjs.SITENAV)} );
