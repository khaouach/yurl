/* compatability for mootools and other frameworks */
jQuery.noConflict();