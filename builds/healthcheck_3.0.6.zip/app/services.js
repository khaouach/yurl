var storyboardServices = angular.module('storyboardServices', ['ngResource']);

storyboardServices.factory('Sites', ['$resource',
  function($resource){
    return $resource(rootDataServer, {}, {
      getLastRun : {
          method:'GET'
          , params:{            
            'unit': 'run',
            'act': 'get_last'}
        },
        
      list : {
          method:'GET'
          , params:{            
            'unit': 'run',
            'act': 'get_data'}
          , isArray:true
      },
      
      get : {
          method:'GET'
          , params:{            
            'unit': 'run',
            'act': 'get_site'}
          , isArray:false
      },
      update: {
        method:'GET'
          , params:{            
            'unit': 'run',
            'act': 'site_update'}
          , isArray:false  
      }
      });
      
 }]);

