<?php

defined('_JEXEC') or die('Restricted access');

class Database {

    private static $mysqli;
    public static $DATE_FORMAT = "d-m-Y H:i:s";
    public static $DATE_SQL_FORMAT = "Y-m-d H:i:s";

    //inits db if first time and returns connection handle 
    static function init() {
        //Create connection
        if (self::$mysqli == null) {
            self::$mysqli = new mysqli(
                    Config::$host
                    , Config::$user
                    , Config::$password
                    , Config::$db);

            //Check connection
            if (mysqli_connect_errno(self::$mysqli)) {
                echo "Error: Failed to connect to MySQL: " . mysqli_connect_error();
                echo "host" . Config::$host;
                die();
            }
        }

        return self::$mysqli;
    }

    static function closeDbo() {
        mysqli_close(self::init());
    }

    static function query($sql, $classObject) {
        $result = mysqli_query(self::$mysqli, $sql);

        while ($row = mysqli_fetch_array($result)) {
            echo $row['FirstName'] . " " . $row['LastName'];
            echo "<br>";
        }
    }

    
    
     static function get_run_id($timestamp) {
        if($timestamp==null){
            $select = "select * from runs where id = (select max(id) from runs)";
        }else{
            $select = sprintf("select * from runs where UNIX_TIMESTAMP(timestamp) = %d ", $timestamp);
        }
        

        self::init();
        $result = mysqli_query(self::$mysqli, $select);
        if ($result) {
            $sites = array();
            $row = mysqli_fetch_object($result);


            return $row;
        } else {
            return $result;
        }
    }
    
    static function get_status_overview($run_id){
        $select = self::get_sql_sitedata($run_id);
        $sql = sprintf("select status, count(status) as size from (%s) as statuses group by status ", $select);
 
        self::init();
        $result = mysqli_query(self::$mysqli, $sql);
        $sites = array();
        if ($result) {
            
            while ($row = mysqli_fetch_object($result)) {             
                $sites[] = $row;
            }
        }
        return $sites;
        
    }
    
    private static function get_sql_sitedata($run_id){
        $select = sprintf("select st.site_id, st.status, st.http_code, st.id as status_id, st.raw, r.`timestamp`, s.environment, s.url, s.url_site , s.application, s.`type`, s.remarks from statuses st 
                        join (
                            select `statuses`.`site_id` AS `site_id`,max(`statuses`.`run_id`) AS `run_id` from `statuses` where run_id <= %d group by `statuses`.`site_id`
                            ) ls on st.run_id = ls.run_id and st.site_id = ls.site_id
                                                        join runs r on r.id = st.run_id
                                                        join sites s on s.id = st.site_id
                                                        order by st.site_id, r.`timestamp`", $run_id);
        return $select;
    }
    
    static function get_sites_data($run_id) {
        self::init();
        //if ($run_id == null) {
        $select = self::get_sql_sitedata($run_id);
                
//        echo $select;
        $result = mysqli_query(self::$mysqli, $select);
        
//        sysout($select);
        
        if ($result) {
            $sites = array();
            while ($row = mysqli_fetch_object($result)) {     
                $pos = strpos($row->raw, "version:");
                $status = Parser::parse_raw_data($row->raw);
                //$row->version = strip_tags(substr($row->raw, $pos, strlen($row->raw)));
                $row->status = $status;
                
                $row->timestamp = DateHelper::dateTimeStringFromSQL($row->timestamp);
                $sites[] = $row;
            }

            return $sites;
        } else {
            return $result;
        }
     
    }
    
    
    /**
     * get all sites
     * @return type
     */
    static function get_sites() {
        self::init();
        //if ($run_id == null) {
        $select = sprintf("select *, id as site_id from sites;");
                
        $result = mysqli_query(self::$mysqli, $select);
        $sites = array();
        if ($result) {
            
            while ($row = mysqli_fetch_object($result)) {             
                $sites[] = $row;
            }
        }
        return $sites;
    }
//    /**
//     * returns the site + status
//     * @param type $run_id  
//     * @return \Site
//     */
//
//    static function get_sites_status($all = true) {
//        self::init();
//        $select = ("select * from sites where 1=1 ");
//        if ($all == false) {
//            $select .= (" and javascript = 0");
//        }
//
//        $result = mysqli_query(self::$mysqli, $select);
//        if ($result) {
//            $sites = array();
//            while ($row = mysqli_fetch_array($result)) {
//                $site = new Site();
//                $site->id = $row['id'];
//                $site->app = $row['application'];
//                $site->type = $row['type'];
//                $site->env = $row['environment'];
//                $site->url = $row['url'];
//                $site->js = ($row['javascript'] == 1 ? true : false);
//                $sites[] = $site;
//            }
//
//            return $sites;
//        } else {
//            return $result;
//        }
//        self::closeDbo();
//    }
//
//    static function truncate_statuses() {
//        self::init();
//        $select = sprintf("truncate table statuses");
//        $retval = mysqli_query(self::$mysqli, $select);
//        return $retval;
//    }
//
//    
    /**
     * Called by deamon
     * @param type $status
     * @return type
     */
    static function insert_site_status($status) {
        self::init();
        $select = sprintf("insert into statuses (site_id, raw, status, run_id, http_code) values (%d, '%s', '%s', %d, '%s') ; "
                , $status->site_id, $status->raw, $status->status, $status->run_id, $status->http_code);
        $retval = mysqli_query(self::$mysqli, $select);
        return $retval;
    }
    
    /**
     * Called by deamon
     * @param type $datetime
     * @return type
     */
    static function insert_run($datetime) {
        self::init();
        $select = sprintf("insert into runs (timestamp) values ('%s');", $datetime->format('Y-m-d H:i:s'));
        mysqli_query(self::$mysqli, $select);
        $retval = self::$mysqli->insert_id;
        return $retval;
    }
//    
//    static function insert_incident($incident) {
//        self::init();
//        $timestamp = DateTime::createFromFormat(Database::$DATE_FORMAT, $incident->timestamp);
//        //$timestamp->setDate($year, $month, $day);
//        $select = sprintf("insert into incidents (`site_id`, `call_im`, `timestamp`, `by`, `remarks`) values (%d, '%s', '%s', '%s', '%s');",$incident->site_id, $incident->call_im, $timestamp->format('Y-m-d H:i:s'), $incident->by, $incident->remarks);
//        mysqli_query(self::$mysqli, $select);
//        $retval = self::$mysqli->insert_id;
//        return $retval;
//    }
//    
//    static function get_incident($site_id, $timestamp){
//        self::init();
//        $select = sprintf("select * from incidents where site_id = %d and timestamp = '%s' ", $site_id, $timestamp->format(Database::$DATE_SQL_FORMAT));
//        $result = mysqli_query(self::$mysqli, $select);
//        if ($result) {            
//            $row = mysqli_fetch_object($result);
//            return $row;
//        } else {
//            return $result;
//        }
//    }
//    
//    /**
//     * geeft een lijst per site_id de meest recente run_id van een change, kan gebruikt worden om een slice in tijd te maken
//     * @param type $run_id
//     * @return type
//     */
//    static function get_most_recent_status_by_run_id($run_id){
//        self::init();
//        $select = sprintf("select `statuses`.`site_id` AS `site_id`, max(`statuses`.`run_id`) AS `run_id` from `statuses` 
//                        where statuses.run_id <= %d
//                        group by `statuses`.`site_id`", $run_id);
//        $result = mysqli_query(self::$mysqli, $select);
//        
//        $results = array();
//        if ($result) {   
//            while ($row = mysqli_fetch_object($result)) {
//                $results[]= $row;                
//            }
//            
//        } 
//        
//        return $result;
//        
//    }
//
//    static function get_stats($status = null) {
//        self::init();
//        $select = "select run_id, UNIX_TIMESTAMP(timestamp) * 1000 + (1000 * 60 * 60 * 2) as x,
//                count(1)  as 'y'
//                    from run_statuses where timestamp >= DATE_ADD(CURDATE(), INTERVAL -14 DAY) group by run_id";
//        $result = mysqli_query(self::$mysqli, $select);
//
//        $results = array();
//        if ($result) {
//            while ($row = mysqli_fetch_object($result)) {
//                $results[] = array(floatval($row->x), intval($row->y));
//            }
//        }
//        
//        return $results;
//    }
//    
    /**
     * Called by deamon
     * @param type $site_id
     * @return \Site
     */
    static function get_latest_status_for_site($site_id){
          self::init();
        $select = sprintf(" select * from statuses s
            left join runs r on r.id = s.run_id
            where s.id = (select max(s2.id)  from statuses s2 where site_id =%d)", $site_id);
        $result = mysqli_query(self::$mysqli, $select);
        
        $results = array();
        if ($result) {   
            while ($row = mysqli_fetch_object($result)) {
                $results[]= $row;                
            }            
        } 
        if(count($results) > 0){
            return $results[0];            
        }else{
            $site = new Site();
            $site->raw = null;
            return $site;
                 
        }
    }
//    
//    
//    
//static function get_last_change_date($timestamp){
//    $dStart = DateTime::createFromFormat(Database::$DATE_SQL_FORMAT, $timestamp);
//    $dEnd = new DateTime();
//    $dDiff = $dStart->diff($dEnd);
//
//    $last_change = "";
//    if($dDiff->m > 0){
//        $last_change .= sprintf(" %d Months", $dDiff->m);
//    }
//    if($dDiff->d > 0){
//        $last_change .= sprintf(" %d days", $dDiff->d);
//    }
//    if($dDiff->h > 0){
//        $last_change .= sprintf(" %d hours", $dDiff->h);
//    }
//    if($dDiff->i > 0){
//        $last_change .= sprintf(" %d min", $dDiff->i);
//    }
//    return $last_change;
//}
//    
//    static function timestamp_from_highcharts($timestamp){
//        $t1 = ($timestamp - (1000 * 60 * 60 * 2)) / 1000;
//        return $t1;
//    }
//    
//    static function timestamp_to_highcharts($timestamp){
//        $t1 = (intval($timestamp) * 1000) + (1000 * 60 * 60 * 2);        
//        return $t1;
//    }
//
//    /**
//     * data for main chart
//     * 
//     */
//    static function _get_stats($status = null){
//        $select = "select run_id, UNIX_TIMESTAMP(timestamp) as timestamp,
//                count(CASE 
//                        WHEN status = 'ok'
//                        THEN 1 
//                        ELSE NULL END)  as 'ok'
//
//                , count(CASE 
//                        WHEN status = 'nok'
//                        THEN 1 
//                        ELSE NULL 
//                END)  as 'nok'
//
//                    from run_statuses where timestamp >= DATE_ADD(CURDATE(), INTERVAL -14 DAY) group by run_id";
//        
//        
//        self::init();
//        $result = mysqli_query(self::$mysqli, $select);
//        if ($result) {
//            $sites = array("ok", "nok");
//            $sites["ok"] = array();
//            $sites["nok"] = array();
//            $count = 0;
//            $prev_row = null;
//            while ($row = mysqli_fetch_object($result)) {
//                $row->added = false;
//                if($row->ok <> $count){
//                    
//                    //oke add previous status to display cutoff
//                    if($prev_row!=null && $prev_row->added == false){
//                        //$sites[] = array(intval($prev_row->timestamp) * 1000 + (1000 * 60 * 60 * 2), intval($prev_row->ok));                    
//                      //  $site = new stdClass();
//                       // $site->run_id = intval($prev_row->run_id);
//                        $sites["ok"][] = array(Database::timestamp_to_highchartsintval($prev_row->timestamp), intval($prev_row->ok));                    
//                        $sites["nok"][] = array(Database::timestamp_to_highchartsintval($prev_row->timestamp) , intval($prev_row->nok));                    
//                    
//                    }
//                    
//                    //$site = new stdClass();
//                    //$site->run_id = intval($row->run_id);
//                    $sites["ok"][] = array(Database::timestamp_to_highchartsintval($row->timestamp), intval($row->ok));                    
//                    $sites["nok"][] = array(Database::timestamp_to_highchartsintval($row->timestamp), intval($row->nok));               
//                    
//                    $count = $row->ok;
//                    $row->added = true;
//                }
//                
//                $prev_row = $row;
//            }
//            
//            //always add the most recent
//            //$site = new stdClass();
//            //$site->run_id = intval($prev_row->run_id);
//            $sites["ok"][] = array(Database::timestamp_to_highchartsintval($prev_row->timestamp), intval($prev_row->ok));                    
//            $sites["nok"][] = array(Database::timestamp_to_highchartsintval($prev_row->timestamp), intval($prev_row->nok));                    
//
//            
//            return $sites;
//        } else {
//            return $result;
//        }
//        
//    }
//    
//   
//    /**
//     * returns all information about a site
//     * @param type $id
//     * @return type
//     */
    static function get_site($id){
        self::init();
        $site = new stdClass();
//        print_r($id);
//        echo $id;
        $selectSites = sprintf("select * from sites where id  = %d ", $id);      
        $result = mysqli_query(self::$mysqli, $selectSites);
        if ($result) {
            $site = mysqli_fetch_object($result);
        }

       
//        $select = sprintf("select st.status, st.id as status_id, st.raw, r.`timestamp`, s.id as site_id, s.environment, s.url, s.url_site , s.application, s.`type`, s.remarks from statuses st 
//                        join latest_statuses ls on st.run_id = ls.run_id and st.site_id = ls.site_id
//                        join runs r on r.id = st.run_id
//                        join sites s on s.id = st.site_id
//                        where st.site_id = %d order by r.`timestamp`;", $id);
//       
//
//        
//        $result = mysqli_query(self::$mysqli, $select);
//        if ($result) {
//            $site->statuses = array();
//            while ($row = mysqli_fetch_object($result)) {     
//                $pos = strpos($row->raw, "version:");
//                $row->version = strip_tags(substr($row->raw, $pos, strlen($row->raw)));
//                $site->statuses[] = $row;
//            }            
//        }
        
        $select = sprintf("select * from statuses s left join runs r on r.id = s.run_id where s.site_id = %d order by timestamp desc limit 0, 30", $id);
        $result = mysqli_query(self::$mysqli, $select);
        if ($result) {
            $site->runs = array();
            while ($row = mysqli_fetch_object($result)) {     
                $status = Parser::parse_raw_data($row->raw);
                //unset($row->raw);
//                sysout($status);
                $row->version = $status->version;                
                $site->runs[] = $row;
            }            
        }
            
        /** incidents **/
        $site->incidents = array();
        $select = sprintf("select *, UNIX_TIMESTAMP(timestamp) as unixtime from incidents where site_id = %d and timestamp >= DATE_ADD(CURDATE(), INTERVAL -14 DAY) ", $id);
        $result = mysqli_query(self::$mysqli, $select);
         while ($row = mysqli_fetch_object($result)) {
             $site->incidents[] = array(intval($row->unixtime) * 1000 + (1000 * 60 * 60 * 2), 0.5);
         }                          
             
         $site->uptime = self::get_site_uptime($id);
             
        return $site;
       
        
    }
    
    static function update_site($id, $url , $url_site, $remarks){
        self::init(); 
        $update = sprintf("update sites s set url = '%s', url_site = '%s', remarks='%s'  where s.id = %d", $url, $url_site, $remarks,  $id);
        $result = mysqli_query(self::$mysqli, $update);
        return $result;
    }
//    
//    
//    
//    static function get_sites_status_all($id) {
//        self::init();        
//        $results_array = array();
//        $select = sprintf(" select * from runs r left join statuses u on r.id = u.run_id
//            where u.site_id = %d", $id);
//        $result = mysqli_query(self::$mysqli, $select);
//        if ($result) {
//            $sites = array();
//            $count = 0;
//            $prev_row = null;
//            while ($row = mysqli_fetch_object($result)) {
//                $results_array[] = $row;
//            }
//            
//        }
//        return $results_array;
//        
//    }
//    
//    static function delete_status($status_id) {
//        self::init();
//        
//        //$timestamp->setDate($year, $month, $day);
//        $select = sprintf("delete from statuses where id = %d", $status_id);
//        mysqli_query(self::$mysqli, $select);       
//        
//    }
//    
//    
//    static function get_site_detail($id, $timestamp) {
//        self::init();
//        $date = new DateTime();
//        $date->setTimestamp($timestamp);
//        $select = sprintf(" select * from runs r left join statuses u on r.id = u.run_id
//            where u.site_id = %d and r.timestamp = '%s' ", $id, $date->format(Database::$DATE_SQL_FORMAT));
//        $result = mysqli_query(self::$mysqli, $select);
//
//        return mysqli_fetch_object($result);
//    }
//    
    /**
     * calculates up time of a site
     * @param type $site_id
     * @return type
     */
    static function get_site_uptime($site_id){
        self::init();
        $select  = sprintf("select UNIX_TIMESTAMP(timestamp) , status from run_statuses where 
                        site_id = %d order by timestamp ", $site_id);
                            //. " and timestamp >= DATE_ADD(CURDATE(), INTERVAL -14 DAY)" 
                            //. "order by timestamp  ";
        
        $result = mysqli_query(self::$mysqli, $select);            
            
        return 100;
    }
    
//    static function get_uptimes(){
//        $sites = self::get_sites();
//        
//        foreach($sites as $site){
//            $sites[$site->site_id] = self::get_site_uptime($site->site_id);
//        }
//        
//    }

}