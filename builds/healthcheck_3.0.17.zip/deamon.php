<?php

define('_JEXEC', getcwd());
define('JPATH_SITE', getcwd());

require_once("classes.healthcheck.php");
require_once("config.php");
require_once("database.php");
require_once('pwframework/ipwframework.php');
$sites = Database::get_sites(false);

//test each site
$run_id = Database::insert_run(new DateTime());

foreach ($sites as $site) {
    try {
        $status = new Status();
        $status->site_id = $site->id;
        $status->run_id = $run_id;

        //haal html op van de site
//        $page = get_http_code($site->url);
        
        //haal laatste status op uit de database
        $site_db_status = Database::get_latest_status_for_site($site->id);
            
//        if ($page->http_code >= 200 && $page->http_code < 300) {
//           
//        }
        
        $data = @file_get_contents($site->url);
        $st = Parser::parse_raw_data($data);

        printf("<li>%s - %s :  %s </li>", $site->application, $site->environment , strip_tags($data));
        
        if ($st->status == null) {
            $status->status = "nok";
        } else {
            $status->status = strtolower($st->status);
        }
        
    } catch (Exception $ex) {
        $status->status = "nok";
    }
        
    $status->http_code = ""; //$page->http_code;
    
    if($data){
        $status->raw = $data;
    }else{
        $status->raw = "";
    }
    
    //on any change we save 
    if ($site_db_status->id==null || $site_db_status->raw <> $status->raw) {
        Database::insert_site_status($status);
    }
}

function get_http_code($p_url) {
    $proxy_ip = "nl-proxy-access.net.abnamro.com";
    $proxy_port = "8080";
    $proxy_loginpassw = "branches\\jo3353:access11";

    $url = trim($p_url);
    $agent = "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERAGENT, $agent);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_VERBOSE, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);

//    $headers = array("HTTP/1.1",
//        "Content-Type: application/x-www-form-urlencoded",
//        "Authorization: Basic " . $proxy_loginpassw
//    );
//    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
//    $fh = fopen(getcwd() . '/test.txt', 'w') or die("can't open file"); //File to write the header information of the curl request.
//    curl_setopt($ch, CURLOPT_STDERR, $fh);
//    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

//    curl_setopt($ch, CURLOPT_HEADER, 0);
//    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//    curl_setopt($ch, CURLOPT_PROXYPORT, $proxy_port);
//    curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
//    curl_setopt($ch, CURLOPT_PROXY, $proxy_ip);
//    curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxy_loginpassw);
//    curl_setopt($ch, CURLOPT_CAINFO, getcwd() . "/cert/cacert.pem");

//    // Turn on SSL certificate verfication
//    curl_setopt($ch, CURLOPT_CAPATH, getcwd() . "/cert/backbase.cer");
//    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
//    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);

//    curl_setopt($ch, CURLOPT_SSLVERSION, 3);
    $html = curl_exec($ch);
    //echo curl_error($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    $page = new stdClass();
    $page->html = $html;
    $page->http_code = $httpcode;
    
    curl_close($ch);
//       if($httpcode>=200 && $httpcode<300) return true;
//       else return false;


    return $page;
}
