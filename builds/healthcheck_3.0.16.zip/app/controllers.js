var storyboardControllers = angular.module('storyboardControllers', []);

storyboardControllers.controller('ItemListCtrl', ['$scope','$http', '$interval', 'Sites',
    function ($scope,$http, $interval, Sites) {
        
        //defaulting paging settings
        $scope.currentPage = 0;
        $scope.pageSize = 20;
        //set default order status
        $scope.orderProp = 'status.status';
        
        $interval(function () {
            Sites.getLastRun(function(run){
                console.log('checking for new data');
                if(run.id !== $scope.last_run.id){
                    //only update when there is a new run
                    $scope.items = Sites.list();
                    $scope.last_run = run;
                }else{
                    return false;
                }

                console.log('refreshing');
            });
            
            
            
        }, refreshRate);
            
        //inital load of items
        Sites.list(function(items){
            $scope.items = items;            
        });
        
        //controller function :: adding paging for more details look here http://jsfiddle.net/2ZzZB/56/
        $scope.numberOfPages=function(){
            if($scope.items===null || $scope.items===undefined){
                return 0;
            }else{
                return Math.ceil($scope.items.length/$scope.pageSize);                                
            }

        };
        
        //controller function :: 
        $scope.siteInDialog = function(site, url_site){
            fnSiteInDialog(site, url_site);
        };

        //initial latest run information
        $scope.last_run = Sites.getLastRun();        
        
    }]);

storyboardControllers.controller('ItemDetailCtrl', ['$scope','$location', 'Sites', '$routeParams',
    function ($scope, $location, Sites, $routeParams) {
        $routeParams.itemId;
        $scope.item = Sites.get({id: $routeParams.itemId});

        var barclass = "progress-bar-success";
        if ($scope.item.uptime < 60) {
            barclass = "progress-bar-danger";
        } else if ($scope.item.uptime < 70) {
            barclass = "progress-bar-warning";
        } else if ($scope.item.uptime < 80) {
            barclass = "progress-bar-info";
        } 
        
        $scope.bar_class = barclass;
        
        $scope.save = function(){
            console.log('saving.');            
            Sites.update({
                id: $routeParams.itemId
                , url : $scope.item.url
                , url_site : $scope.item.url_site
                , remarks : $scope.item.remarks
            }, function(data){                
                if(data.result===true){
                    bootbox.alert("Save was successful");
                }
            });
        };
        
        //controller function :: 
        $scope.delete = function(){
            bootbox.confirm('Are you sure', function(result){
                if(result){
                    Sites.remove({id: $routeParams.itemId}, function(r){
                        if(r.result){
                            $location.path('/items');
                        }else{
                            bootbox.alert('Delete failed');
                        }
                        
                    });
                    
                }
            });
        };
        
        //controller function :: 
        $scope.siteInDialog = function(site, url_site){
            fnSiteInDialog(site, url_site);
        };
    }
]);


