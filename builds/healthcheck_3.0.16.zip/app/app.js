(function () {

   var storyboardApp = angular.module('storyboardApp', [ 
       'ngRoute',
       'storyboardAnimations',
       'storyboardServices',
       'storyboardControllers']);

    storyboardApp.config(['$routeProvider',
        function ($routeProvider) {
            $routeProvider.
                    when('/items', {
                        templateUrl: 'app/partials/main-overview.html',
                        controller: 'ItemListCtrl'
                    }).
                    when('/items/:itemId', {
                        templateUrl: 'app/partials/item-details.html',
                        controller: 'ItemDetailCtrl'
                    }).
                    otherwise({
                        redirectTo: '/items'
                    });
        }]);
    
    //We already have a limitTo filter built-in to angular,
    //let's make a startFrom filter
    storyboardApp.filter('startFrom', function() {
        return function(input, start) {
            start = +start; //parse to int
            if(input===undefined){
                return null;
            }else{
                return input.slice(start);
            }
        
        };
    });
  

})();