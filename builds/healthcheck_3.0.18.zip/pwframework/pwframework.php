<?php
/** 
 * @package		PWFramework
 * @author    	Pageworks http://www.pageworks.nl
 * @copyright	Copyright (c) 2006 - 2015 Pageworks. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */

 
abstract class PWController {

    public $option = null;
    public $unit = null;
    public $action = null;
    public $Itemid = null;

}

class PWAction {

    private $name = null;
    private $params = array();
    private $wrapAdminForm = false;
    private $unit_name = null;
    private $token = false;

    public function __construct($unit_name, $name) {
        $this->name = $name;
        $this->unit_name = $unit_name;
    }

    /**
     * if set to true a joomla security token is checked on execution
     * @param type $token
     * @return \PWAction
     */
    public function token($token = false) {
        $this->token = $token;
        return $this;
    }

    public function execute($option, $Itemid) {

        /* validate joomla security token */
        if ($this->token) {
//            if (!(JSession::checkToken() || JSession::checkToken('get'))) {
//                JFactory::getApplication()->enqueueMessage("Invalid token");
//                return false;
//            }
        }

        $className = "PWTask" . ucwords($this->unit_name);
        $cls = new $className;
        //setting class basic value
        $cls->action = $this->name;
        $cls->unit = $this->unit_name;
        $cls->option = $option;
        $cls->Itemid = $Itemid;
        

        if (class_exists($className) && method_exists($cls, $this->name())) {
            $params = $this->getParameterValues();
            call_user_func_array(array($cls, $this->name()), $params);
        } else {
            JFactory::getApplication()->enqueueMessage("class " . $className . " with method " . $this->name . " could not be called because it does not exists");
            return;
        }
    }

    /**
     * Add a parameter
     * @param type $param
     * @return \PWAction
     */
    public function param($param) {
        $this->params[] = $param;
        return $this;
    }

    /**
     * set an array of parameters
     * @param type $params
     * @return \PWAction11
     */
    public function params($params) {
        $this->params = $params;
        return $this;
    }

    public function name() {
        return $this->name;
    }

    public function wrapAdminForm($wrap) {
        $this->wrapAdminForm = $wrap;
        return $this;
    }

    private function getParameterValues() {

        $jinput = JFactory::getApplication()->input;

        if ($this->params == null) {
            return array();
        }

        if (!is_array($this->params)) {
            die("false parameter array supplied for " . $this->name);
        }
        $retval = array();

        foreach ($this->params as $param) {
            /* arrays need different approach */
            $param_value = $jinput->getString($param);
            if ($param_value) {
                //if parameters is set				
                if (is_array($param_value)) {
                    /* iterate trough array */
                    $tmp = $param_value;
                    $rt = array();
                    foreach ($tmp as $key => $t) {
                        $rt[$key] = htmlspecialchars("" . $t);
                    }
                    $retval[] = $rt;
                } else {
                    $retval[] = htmlspecialchars("" . $param_value);
                }
            } else {
                //oops parameter not set
                $retval[] = null;
            }
        }
        return $retval;
    }

}

class PWUnit {

    private $name = null;

    public function __construct($name) {
        $this->name = $name;
    }

    private $actions = array();

    public function action($action) {
        if (!array_key_exists($action, $this->actions)) {
            $this->actions[$action] = new PWAction($this->name, $action);
        }
        return $this->actions[$action];
    }

    public function getAction($action) {
        if (array_key_exists($action, $this->actions)) {
            return $this->actions[$action];
        }
        return null;
    }

    public function name() {
        return $this->name;
    }

}

class PWCommand {

    private $units = array();
    private $_unit = null;
    private $_action = null;
    private $debug = false;
    
    public function __construct() {
        
    }
    
    public function debug($debug){
        $this->debug = $debug;
        return $this;        
    }

    public function unit($unit) {
        if (!array_key_exists($unit, $this->units)) {
            $this->units[$unit] = new PWUnit($unit);
        }
        return $this->units[$unit];
    }

    public function run($unit_name = null, $act_name = null) {
        $jinput = JFactory::getApplication()->input;
        if ($unit_name == null) {
            $unit_name = $jinput->get('unit');
        }
        if ($act_name == null) {
            $act_name = $jinput->get('act');
        }

        /** getting some handy values for joomla */
        $option = $jinput->get('option');
        $Itemid = $jinput->get('Itemid');

        $this->_unit = $this->unit($unit_name);
        $this->_action = $this->_unit->getAction($act_name);

        if ($this->_action == null) {
            echo "sorry no such action for this option!, " . $unit_name . " => " . $act_name;
            return;
        }

        if($this->debug){
            sysout($_REQUEST);
            sysout($this->_unit);
            sysout($this->_action);
        }
        /* execute the action */
        $this->_action->execute($option, $Itemid);
    }

}

class PWFrameWorks {

    public static function getCommand() {
        return new PWCommand();
    }

}