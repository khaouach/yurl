fnSiteInDialog = function (site, url_site) {
    var url = site.url;
    if (url_site) {
        var url = site.url_site;
    }
    var sWidth = $(window).width();
    var sHeight = $(window).height();
    var title = '<i class="fa fa-globe fa-2x" ></i> ' + site.application + ' - ' + site.environment + ' - ' + site.type + ' - ' + site.version;

    var html = '<iframe width="100%" height="' + (sHeight * 0.7) + '" frameborder="0"  scrolling="n"  allowTransparency="false" src="' + url + '" ></iframe>';
    $('#site-modal .modal-dialog').width(sWidth * 0.8);
    $('#site-modal .modal-title').html(title);
    $('#site-modal .modal-body').html(html);
    $('#site-modal #remarks').html(site.remarks);
    $('#site-modal').modal('show');
}


